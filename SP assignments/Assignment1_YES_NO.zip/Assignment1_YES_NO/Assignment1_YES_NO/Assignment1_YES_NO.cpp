// Assignment1_YES_NO.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
#include<fstream>
#include<vector>
using namespace std;

int Count_STE_ZCR(fstream &myfile,vector<long long int> &ste_values,vector<long long int> &zcr_values)
{
	long long int avg_ste=0,temp,ste=0,zcr=0,avg_zcr=0;
    int count=320;
    int sample_no=0;
    bool pos=true;
	while(myfile>>temp)
    {
		if(temp>=0 && !pos)
        {
            zcr++;
            pos=true;
        }
        else if (temp<0 && pos)
        {
            zcr++;
            pos=false;
        }
        ste=ste+temp*temp;   
        count--;
        if(count==0)
        {
            ste=ste/320;
			ste_values.push_back(ste);
			zcr_values.push_back(zcr);
			avg_zcr+=zcr;
			avg_ste+=ste;
            //cout<<"For sample no: "<<sample_no<<" STE for vowel aa is: "<<sum<<"\n";
            ste=0;
			zcr=0;
            count=320;
            sample_no++;
        }
    }
    //myfile.close();
    avg_ste=avg_ste/(sample_no+1);
    avg_zcr=avg_zcr/(sample_no+1);
	cout<<"average STE for vowel is: "<<avg_ste<<" avg ZCR value is "<<avg_zcr<<endl;
	return sample_no;
}


void check_for_yes_no(const vector<long long int> ste_values,const vector<long long int> zcr_values,int start,int end)
{
	int thr_to_remove_abrupt_thrust_size=10;
	if((end-start)<thr_to_remove_abrupt_thrust_size)
		return;
	/*for(int i=start;i<=end;i++)
	{
		cout<<"Sample No: "<<i<<" STE value ="<<ste_values[i]<<" ZCR value ="<<zcr_values[i]<<endl;
	}*/
	int mid = (end-start)/2;
	long long int avg=0;
	for(int i=mid+start;i<end;i++)
	{
		avg+=zcr_values[i];
	}
	avg=avg/mid;
	cout<<start<<"  "<<end<<"  "<<avg<<"  ";
	if(avg>33)
		cout<<"YES\n";
	else
		cout<<"NO\n";
	//cout<<"\n\n";
	return;
}

int _tmain(int argc, _TCHAR* argv[])
{
	//long long int temp,sum=0;
	vector<long long int> zcr_values;
	vector<long long int> ste_values;
	vector<long long int> data;
	int threshold_silence=1500;
    fstream myfile;
    //myfile.open("D:/Materials/IITG_sem1/SP/demo_sounds/vowel_aa.txt");
    myfile.open("D:/Materials/IITG_sem1/SP/demo_sounds/YES_NO_2.txt");
	//cout<<"ZCR value is "<<Count_ZCR(myfile,zcr_values);
	int sample_no=Count_STE_ZCR(myfile,ste_values,zcr_values);
	myfile.close();
    bool start_marker=true;
	long long int start,end;
	for(int i=0;i<sample_no;i++)
	{
		if(ste_values[i]>threshold_silence && start_marker)
		{
			start_marker=false;										//mark it as start marker;
			start=i;
		}
		else if(ste_values[i]<threshold_silence && !start_marker)
		{
			start_marker=true;
			end=i;
			check_for_yes_no(ste_values,zcr_values,start,end);
		}
	}
	return 0;
}

