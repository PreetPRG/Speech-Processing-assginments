
1. Click on "Recording_Module.exe" file. It gives a command line telling about usage.

Note:
i)Please don't rename, delete or merge any folder. If you do so, you may face some problems.
2)Some dll files are important to run this exe. Copy these files into C:\Windows\System32 folder.
If it is not working copy these files in the directory where "Recording_Module.exe" is there.